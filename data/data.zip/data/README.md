Data included in `input/`:
* `gbif_synonyms_not_accepted_wcvp.tsv`: GBIF taxa for which the scientific names are not listed as accepted synonyms for the reported species according to WCVP v3 (Govaerts et al., 2021; doi: 10.1038/s41597-021-00997-6).
* `non_quercus_hosts.tsv`: Information on non-oak larval _Agrilus_ hosts. Most data come from Jendek & Poláková (2014; doi: 10.1007/978-3-319-08410-7). See the paper for further information.
* `quercus_hosts.tsv`: Information on larval _Agrilus_ oak hosts. Most data come from Jendek & Poláková (2014; doi: 10.1007/978-3-319-08410-7). See the paper for further information.
* `quercus_nodesig_result.nex`: Phylocom v4.2 (Webb et al., 2008; doi: 10.1093/bioinformatics/btn358) nodesig output based on the Hipp et al. (2019) tree and _Agrilus_ host data (see `quercus_hosts.tsv`). Used to identify clades in the oak phylogeny with an over-representation of _Agrilus_ hosts. See the paper for further details.
* `tr.singletons.correlated.1.taxaGrepCrown_accepted_names.tre`: Phylogenetic tree from Hipp et al. (2019; doi: 10.1111/nph.16162; associated repository: github.com/andrew-hipp/global-oaks-2019). Taxonomic names have been cross-referenced with, and updated according to, WCVP v3 (Govaerts et al., 2021; doi: 10.1038/s41597-021-00997-6). If using this phylogeny in your own work, please cite Hipp et al. (2019).

Data included in `results/`:
<!-- * `gbif_geo_plants.tsv`: GBIF geographic information for plant species in the dataset. See `analyses/02_extract_geo_info.r` for details on how this file was generated. -->
* `gbif_geo_plants_clean.tsv`: Cleaned GBIF geographic information for plant species in the dataset. See `analyses/02_extract_geo_info.r` for details on how this file was generated.
* `interaction_data.tsv`: Binary data on _Agrilus_ – oak interactions, as well various predictors computed to be used as variables in the statistical models fitted in `analysis/04_brms_models.r`. See `analysis/03_interaction_dataframe.r` for details on how this file was generated.
