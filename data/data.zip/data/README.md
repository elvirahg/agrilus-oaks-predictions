This folder contains data used as input for the analyses in the `analysis/` directory, as well as data generated throughout the analyses.

Input data:
* `agrilus_quercus_hosts.txt`: Information on larval _Agrilus_ oak hosts. Most data comes from Jendek & Poláková (2014, see doi.org/10.1007/978-3-319-08410-7). See paper for further information.
* `gbif_notwcvp_auth.txt`: File containing information on GBIF taxa for which the scientific name is not listed as an accepted synonym for the reported species according to WCVP v3 (Govaerts et al., 2021; doi: 10.1038/s41597-021-00997-6).
* `no_agrilus_quercus_hosts.txt`: Number of _Agrilus_ species hosted per oak species, inferred using `agrilus_quercus_hosts.txt`.
* `non_oak_hosts.txt`: Information on larval _Agrilus_ non-oak hosts. Most data comes from Jendek & Poláková (2014, see doi.org/10.1007/978-3-319-08410-7). See paper for further information.
* `quercus_hipp19_singleton_crown_sp_level.tre`: Phylogenetic tree from Hipp et al. (2019; doi: 10.1111/nph.16162; associated repository: github.com/andrew-hipp/global-oaks-2019). If using this phylogeny in your own work, please cite Hipp et al. (2019).
* `quercus_nodesig_result.nex`: Phylocom v4.2 (Webb et al., 2008; doi: 10.1093/bioinformatics/btn358) nodesig output based on the Hipp et al. (2019) phylogeny (see `tr.singletons.correlated.1.taxaGrepCrown_accepted_names.tre`) and _Agrilus_ host data (see `agrilus_quercus_hosts.txt`). Used to identify clades in the oak phylogeny with an over-representation of _Agrilus hosts_. See the paper for further details.
* `tr.singletons.correlated.1.taxaGrepCrown_accepted_names.tre`: Phylogenetic tree from Hipp et al. (2019; doi: 10.1111/nph.16162; associated repository: github.com/andrew-hipp/global-oaks-2019). Taxonomic names have been cross-referenced with, and updated according to, WCVP v3 (Govaerts et al., 2021; doi: 10.1038/s41597-021-00997-6). If using this phylogeny in your own work, please cite Hipp et al. (2019).

Results data:
* `gbif_plants_clean.tsv`: Cleaned GBIF geographic information for plant species in the dataset. See `analysis/02_gbif_geographic_info.R` for details on how this file was generated.
* `interaction_data_oak_hosts.txt`: Binary data on _Agrilus_ – oak interactions, as well various metrics computed to be used as predictors in the statistical models fitted in `analysis/04_brms_models.R`. See `analysis/03_interaction_matrix.R` for details on how this file was generated.
* `predictions_loo0.tsv`: One-as-zero "leave-one-out"-like predictions generated in `analysis/07_leave_one_out_analysis.R`, see script for further details.
